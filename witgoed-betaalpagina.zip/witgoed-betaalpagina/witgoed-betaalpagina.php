<?php
/**
 * Plugin Name: Apparatenman – Professionele Betaal- & Bedankpagina
 * Description: Maakt van de standaard WooCommerce "Betaal je bestelling"-pagina een professionele, inlogvrije afrekenpagina in de Apparatenman-huisstijl. De klant vult zelf zijn factuur-/verzendgegevens in; artikel en prijs staan vast. Voegt daarnaast een bedankpagina in huisstijl toe die geldt voor álle bestellingen. Werkt met Mollie Payments for WooCommerce.
 * Version: 1.2.4
 * Author: Apparatenman
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * Text Domain: witgoed-betaalpagina
 * Update URI: false
 *
 * Changelog:
 *  1.2.4 – "Opnieuw controleren" op de Updates-pagina haalt nu direct de nieuwste versie op (geen wachttijd meer door cache).
 *  1.2.3 – Verwarrende rode melding "Je betaalt voor een gastbestelling" vervangen door een vriendelijke welkomsttekst in huisstijl.
 *  1.2.2 – Handmatig aangemaakte bestellingen vervallen niet meer automatisch; de betaallink blijft geldig totdat er betaald is (of je de order zelf annuleert).
 *  1.2.1 – Dubbele adresvelden (aparte Straat/Nummer/Toevoeging van adres-splitsende plugins) verborgen op de betaalpagina.
 *  1.2.0 – Automatische updates toegevoegd (toont een "Update beschikbaar"-knop in het dashboard).
 *  1.1.0 – Huisstijl + bedankpagina.
 *  1.0.0 – Eerste versie.
 *
 * Hoe het werkt:
 *  1. Maak in WooCommerce een handmatige bestelling aan (status "In afwachting van betaling").
 *  2. Vul artikel + prijs in en (optioneel) alvast de klantgegevens.
 *  3. Stuur de klant de "Betaalpagina van klant"-link (of e-mail de factuur).
 *  4. De klant landt op een nette pagina in huisstijl, vult/controleert zijn gegevens en
 *     rekent af met de gebruikelijke betaalmethoden (iDEAL, creditcard, Bancontact ... via Mollie).
 *     Er is GEEN account of wachtwoord nodig. Artikel en prijs kan de klant niet wijzigen.
 *  5. Na betaling komt élke klant (ook via de normale webshop-checkout) op de bedankpagina
 *     in huisstijl terecht.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Directe toegang blokkeren.
}

/**
 * ===== AUTO-UPDATE BRON =====
 * URL naar het update-informatiebestand (JSON). Zolang dit bestand bestaat en
 * een hoger versienummer bevat, verschijnt er in WordPress automatisch een
 * "Update beschikbaar"-melding bij deze plugin.
 *
 * Je kunt deze waarde ook in wp-config.php zetten (define('WTBP_UPDATE_URL', '...'))
 * of via de filter 'wtbp_update_url' aanpassen. Leeg laten = auto-update uit.
 * Zie de bureau-instructie voor het aanmaken van dit bestand.
 */
if ( ! defined( 'WTBP_UPDATE_URL' ) ) {
	define( 'WTBP_UPDATE_URL', 'https://raw.githubusercontent.com/AMCoeur/apparatenman-betaalpagina/main/witgoed-betaalpagina.json' );
}

/**
 * Zorg dat WooCommerce actief is voordat we iets doen.
 */
add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p><strong>Apparatenman – Professionele Betaal- & Bedankpagina</strong> vereist dat WooCommerce actief is.</p></div>';
		} );
	}
} );

/* =========================================================================
 * 0. HUISSTIJL (kleuren, lettertype, logo)
 * =========================================================================
 * Automatisch afgeleid van apparatenman.nl. Alles is via de filter
 * 'wtbp_brand' aan te passen (zie handleiding), zodat je nooit door de
 * plugincode hoeft te zoeken om een kleur te wijzigen.
 * ========================================================================= */
function wtbp_brand() {
	return apply_filters( 'wtbp_brand', array(
		'primary'     => '#1e61b9', // Apparatenman blauw
		'primary_dark'=> '#17509c',
		'dark'        => '#172635', // Donker marineblauw (titels)
		'accent'      => '#14b457', // Groen – primaire actieknop (Betalen)
		'accent_dark' => '#109a4a',
		'surface'     => '#f5f7f9', // Lichtgrijze achtergrond
		'border'      => '#e3e8ee',
		'text'        => '#1f2a37',
		'muted'       => '#5b6875',
		'radius'      => '12px',
		'font'        => '"Albert Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
		'logo'        => 'https://apparatenman.nl/app/uploads/2025/08/Group-1990.svg',
	) );
}

/**
 * Logo-URL: gebruik het WordPress-sitelogo als dat is ingesteld, anders het
 * bekende Apparatenman-logo.
 */
function wtbp_logo_url() {
	$brand = wtbp_brand();
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$src = wp_get_attachment_image_src( $logo_id, 'full' );
		if ( ! empty( $src[0] ) ) {
			return $src[0];
		}
	}
	return $brand['logo'];
}

/* =========================================================================
 * 1. GEEN INLOG / GEEN WACHTWOORD NODIG OM TE BETALEN
 * =========================================================================
 * Standaard vraagt WooCommerce de klant om in te loggen of zijn e-mail te
 * verifiëren wanneer de bestelling aan een geregistreerde klant hangt.
 * We geven de betaalrechten vrij, maar ALLEEN als de order-key in de URL
 * klopt (dat is de beveiliging die WooCommerce zelf ook gebruikt).
 * ========================================================================= */

// E-mailverificatiescherm op de betaalpagina uitzetten.
add_filter( 'woocommerce_order_email_verification_required', '__return_false', 9999 );

// Betaalrechten toekennen bij een geldige order-key.
add_filter( 'user_has_cap', function ( $allcaps, $caps, $args ) {
	if ( isset( $caps[0], $_GET['key'] ) && 'pay_for_order' === $caps[0] ) {
		$order_id = isset( $args[2] ) ? absint( $args[2] ) : 0;
		$order    = $order_id ? wc_get_order( $order_id ) : false;

		if ( $order && hash_equals( (string) $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ) ) ) ) {
			$allcaps['pay_for_order'] = true;
		}
	}
	return $allcaps;
}, 9999, 3 );

/* =========================================================================
 * 1a. HANDMATIGE BESTELLINGEN VERVALLEN NOOIT AUTOMATISCH
 * =========================================================================
 * WooCommerce annuleert onbetaalde bestellingen standaard na de "voorraad
 * vasthouden"-tijd (Instellingen → Producten → Voorraad). Voor bestellingen
 * die jij in het beheer aanmaakt is dat ongewenst: de betaallink moet
 * desnoods weken geldig blijven. Webshop-bestellingen van klanten houden het
 * normale gedrag, zodat voorraad daar niet eindeloos vastgehouden wordt.
 * Via de filter 'wtbp_never_expire' is dit gedrag aan te passen.
 * ========================================================================= */
add_filter( 'woocommerce_cancel_unpaid_order', function ( $cancel, $order ) {
	if ( ! $cancel || ! $order instanceof WC_Order ) {
		return $cancel;
	}

	// 'admin' = handmatig aangemaakt in het WooCommerce-beheer.
	$is_manual    = ( 'admin' === $order->get_created_via() );
	$never_expire = apply_filters( 'wtbp_never_expire', $is_manual, $order );

	return $never_expire ? false : $cancel;
}, 9999, 2 );

/* =========================================================================
 * 1a-2. VRIENDELIJKE MELDING I.P.V. "JE BETAALT VOOR EEN GASTBESTELLING"
 * =========================================================================
 * WooCommerce toont op de betaalpagina bij gastbestellingen een rode
 * waarschuwing ("Je betaalt voor een gastbestelling. Ga alleen door ...").
 * Dat oogt als een foutmelding en wekt de indruk dat er een account nodig
 * is. Omdat jouw klanten de link rechtstreeks van jou krijgen, vervangen we
 * de tekst door een geruststellende welkomstboodschap; de styling wordt in
 * sectie 7 omgezet naar een rustige informatiebalk in huisstijl.
 * ========================================================================= */
add_filter( 'gettext', function ( $translation, $text, $domain ) {
	if ( 'woocommerce' === $domain && false !== strpos( $text, 'You are paying for a guest order' ) ) {
		if ( function_exists( 'is_wc_endpoint_url' ) && ! is_admin() ) {
			$translation = __( 'Welkom! Dit is jouw persoonlijke betaalpagina. Controleer hieronder je gegevens en rond de betaling veilig af.', 'witgoed-betaalpagina' );
		}
	}
	return $translation;
}, 10, 3 );

/* =========================================================================
 * 1b. HELPERS: VELDEN OPSCHONEN OP DE BETAALPAGINA
 * =========================================================================
 * Sommige plugins (o.a. PostNL/MyParcel) splitsen het adres in aparte velden
 * "Straat", "Nummer" en "Toevoeging" naast het standaardveld "Straat en
 * huisnummer". Dat oogt dubbel; we verbergen de splits-velden hier.
 * Daarnaast maken we het telefoonnummer verplicht.
 * Beide gedragingen zijn via filters aan te passen.
 * ========================================================================= */

/** Moet dit veld verborgen worden op de betaalpagina? */
function wtbp_is_hidden_field( $key ) {
	$patterns = apply_filters( 'wtbp_hidden_field_patterns', array( 'street_name', 'house_number' ) );
	foreach ( $patterns as $pattern ) {
		if ( false !== strpos( $key, $pattern ) ) {
			return true;
		}
	}
	return false;
}

/** Velden die op de betaalpagina altijd verplicht zijn. */
function wtbp_forced_required_fields() {
	return apply_filters( 'wtbp_required_fields', array( 'billing_phone' ) );
}

/* =========================================================================
 * 2. HELPER: HUIDIGE BESTELLING OP DE BETAALPAGINA OPHALEN
 * ========================================================================= */
function wtbp_get_current_pay_order() {
	global $wp;

	$order_id = 0;
	if ( isset( $wp->query_vars['order-pay'] ) && $wp->query_vars['order-pay'] ) {
		$order_id = absint( $wp->query_vars['order-pay'] );
	} elseif ( isset( $_GET['order-pay'] ) ) {
		$order_id = absint( $_GET['order-pay'] );
	}

	return $order_id ? wc_get_order( $order_id ) : false;
}

/* =========================================================================
 * 3. KOPBALK MET LOGO BOVEN DE BETAALPAGINA
 * ========================================================================= */
add_action( 'before_woocommerce_pay', 'wtbp_pay_header', 5 );
function wtbp_pay_header() {
	$logo = esc_url( wtbp_logo_url() );
	echo '<div class="wtbp-hero">';
	echo '<img class="wtbp-logo" src="' . $logo . '" alt="Apparatenman" />';
	echo '<h2 class="wtbp-hero-title">' . esc_html__( 'Je bestelling afronden', 'witgoed-betaalpagina' ) . '</h2>';
	echo '<p class="wtbp-hero-sub">' . esc_html__( 'Controleer je gegevens en reken veilig af.', 'witgoed-betaalpagina' ) . '</p>';
	echo '</div>';
}

/* =========================================================================
 * 4. BEWERKBARE FACTUUR- EN VERZENDVELDEN OP DE BETAALPAGINA
 * ========================================================================= */
add_action( 'woocommerce_pay_order_before_submit', 'wtbp_render_address_fields', 5 );
function wtbp_render_address_fields() {
	$order = wtbp_get_current_pay_order();
	if ( ! $order ) {
		return;
	}

	$checkout        = WC()->checkout();
	$billing_fields  = $checkout->get_checkout_fields( 'billing' );
	$shipping_fields = $checkout->get_checkout_fields( 'shipping' );

	$has_diff_shipping = $order->get_shipping_address_1() && (
		$order->get_shipping_address_1() !== $order->get_billing_address_1() ||
		$order->get_shipping_postcode() !== $order->get_billing_postcode()
	);

	echo '<div class="wtbp-fields" id="wtbp-fields">';

	// ---- Factuurgegevens ----
	echo '<div class="wtbp-section">';
	echo '<h3 class="wtbp-title">' . esc_html__( 'Jouw factuurgegevens', 'witgoed-betaalpagina' ) . '</h3>';
	echo '<div class="wtbp-grid">';
	foreach ( $billing_fields as $key => $field ) {
		if ( wtbp_is_hidden_field( $key ) ) {
			continue; // Dubbele splits-velden (Straat/Nummer/Toevoeging) overslaan.
		}
		if ( in_array( $key, wtbp_forced_required_fields(), true ) ) {
			$field['required'] = true;
			$field['label']    = preg_replace( '/\s*\((optioneel|optional)\)\s*/i', '', (string) $field['label'] );
		}
		$getter = 'get_' . $key;
		$value  = is_callable( array( $order, $getter ) ) ? $order->$getter() : '';
		woocommerce_form_field( $key, $field, $value );
	}
	echo '</div>';
	echo '</div>';

	// ---- Toggle afwijkend verzendadres ----
	echo '<p class="form-row wtbp-toggle-row">';
	printf(
		'<label class="checkbox"><input type="checkbox" class="input-checkbox" name="wtbp_ship_to_different" id="wtbp_ship_to_different" value="1" %s /> <span>%s</span></label>',
		checked( $has_diff_shipping, true, false ),
		esc_html__( 'Verzenden naar een ander adres?', 'witgoed-betaalpagina' )
	);
	echo '</p>';

	// ---- Verzendgegevens ----
	echo '<div class="wtbp-section wtbp-shipping" id="wtbp-shipping" style="' . ( $has_diff_shipping ? '' : 'display:none;' ) . '">';
	echo '<h3 class="wtbp-title">' . esc_html__( 'Verzendadres', 'witgoed-betaalpagina' ) . '</h3>';
	echo '<div class="wtbp-grid">';
	foreach ( $shipping_fields as $key => $field ) {
		if ( wtbp_is_hidden_field( $key ) ) {
			continue;
		}
		$getter          = 'get_' . $key;
		$value           = is_callable( array( $order, $getter ) ) ? $order->$getter() : '';
		$field['required'] = false;
		woocommerce_form_field( $key, $field, $value );
	}
	echo '</div>';
	echo '</div>';

	wp_nonce_field( 'wtbp_save_fields', 'wtbp_fields_nonce' );

	echo '</div>'; // .wtbp-fields
}

/* =========================================================================
 * 5. GEGEVENS OPSLAAN BIJ HET AFREKENEN
 * ========================================================================= */
add_action( 'woocommerce_before_pay_action', 'wtbp_save_address_fields', 10, 1 );
function wtbp_save_address_fields( $order ) {

	if ( ! isset( $_POST['wtbp_fields_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( wc_clean( wp_unslash( $_POST['wtbp_fields_nonce'] ) ), 'wtbp_save_fields' ) ) {
		return;
	}

	$checkout        = WC()->checkout();
	$billing_fields  = $checkout->get_checkout_fields( 'billing' );
	$shipping_fields = $checkout->get_checkout_fields( 'shipping' );
	$errors          = array();

	// ---- Factuurgegevens opslaan + valideren ----
	foreach ( $billing_fields as $key => $field ) {
		if ( wtbp_is_hidden_field( $key ) ) {
			continue; // Verborgen splits-velden niet valideren of overschrijven.
		}
		if ( in_array( $key, wtbp_forced_required_fields(), true ) ) {
			$field['required'] = true;
		}

		$posted = isset( $_POST[ $key ] ) ? wc_clean( wp_unslash( $_POST[ $key ] ) ) : '';

		if ( ! empty( $field['required'] ) && '' === $posted ) {
			$label    = isset( $field['label'] ) ? $field['label'] : $key;
			$errors[] = sprintf( __( '%s is een verplicht veld.', 'witgoed-betaalpagina' ), $label );
			continue;
		}

		if ( 'billing_email' === $key && '' !== $posted && ! is_email( $posted ) ) {
			$errors[] = __( 'Vul een geldig e-mailadres in.', 'witgoed-betaalpagina' );
			continue;
		}

		$setter = 'set_' . $key;
		if ( is_callable( array( $order, $setter ) ) ) {
			$order->$setter( $posted );
		}
	}

	// ---- Verzendgegevens ----
	$ship_to_different = ! empty( $_POST['wtbp_ship_to_different'] );

	if ( $ship_to_different ) {
		foreach ( $shipping_fields as $key => $field ) {
			if ( wtbp_is_hidden_field( $key ) ) {
				continue;
			}
			$posted = isset( $_POST[ $key ] ) ? wc_clean( wp_unslash( $_POST[ $key ] ) ) : '';
			$setter = 'set_' . $key;
			if ( is_callable( array( $order, $setter ) ) ) {
				$order->$setter( $posted );
			}
		}
	} else {
		$map = array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country' );
		foreach ( $map as $part ) {
			$b_getter = 'get_billing_' . $part;
			$s_setter = 'set_shipping_' . $part;
			if ( is_callable( array( $order, $b_getter ) ) && is_callable( array( $order, $s_setter ) ) ) {
				$order->$s_setter( $order->$b_getter() );
			}
		}
	}

	// ---- Fouten? Terug naar de betaalpagina met melding. ----
	if ( ! empty( $errors ) ) {
		foreach ( $errors as $msg ) {
			wc_add_notice( $msg, 'error' );
		}
		wp_safe_redirect( $order->get_checkout_payment_url() );
		exit;
	}

	$order->save();
}

/* =========================================================================
 * 6. BEDANKPAGINA IN HUISSTIJL (geldt voor ÁLLE bestellingen)
 * =========================================================================
 * De WooCommerce "Bestelling ontvangen"-pagina is waar élke betaling na
 * afloop op uitkomt – ook je normale webshop-checkout en andere gateways.
 * We voegen bovenaan een merk-hero toe en daaronder een "Wat gebeurt er nu?"-
 * blok. Het standaard-besteloverzicht blijft gewoon staan.
 * ========================================================================= */

// Hero bovenaan de bedankpagina.
add_action( 'woocommerce_before_thankyou', 'wtbp_thankyou_hero', 5 );
function wtbp_thankyou_hero( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	$name = trim( $order->get_billing_first_name() );
	$logo = esc_url( wtbp_logo_url() );

	echo '<div class="wtbp-thanks-hero">';
	echo '<img class="wtbp-logo" src="' . $logo . '" alt="Apparatenman" />';
	echo '<div class="wtbp-check" aria-hidden="true">&#10003;</div>';

	if ( $order->has_status( 'failed' ) ) {
		echo '<h1 class="wtbp-thanks-title">' . esc_html__( 'De betaling is niet gelukt', 'witgoed-betaalpagina' ) . '</h1>';
		echo '<p class="wtbp-thanks-sub">' . esc_html__( 'Er is iets misgegaan met je betaling. Je kunt het hieronder opnieuw proberen.', 'witgoed-betaalpagina' ) . '</p>';
	} else {
		$greeting = $name
			? sprintf( __( 'Bedankt voor je bestelling, %s!', 'witgoed-betaalpagina' ), esc_html( $name ) )
			: __( 'Bedankt voor je bestelling!', 'witgoed-betaalpagina' );
		echo '<h1 class="wtbp-thanks-title">' . esc_html( $greeting ) . '</h1>';
		echo '<p class="wtbp-thanks-sub">' . sprintf(
			/* translators: %s: order number */
			esc_html__( 'Je bestelling %s is ontvangen en wordt verwerkt.', 'witgoed-betaalpagina' ),
			'<strong>#' . esc_html( $order->get_order_number() ) . '</strong>'
		) . '</p>';
	}
	echo '</div>';
}

// "Wat gebeurt er nu?" – vóór het standaard-besteloverzicht (dat op prio 10 draait).
add_action( 'woocommerce_thankyou', 'wtbp_thankyou_steps', 5 );
function wtbp_thankyou_steps( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order || $order->has_status( 'failed' ) ) {
		return;
	}

	$steps = apply_filters( 'wtbp_thankyou_steps', array(
		array(
			'title' => __( 'Bevestiging per e-mail', 'witgoed-betaalpagina' ),
			'text'  => __( 'Je ontvangt binnen enkele minuten een bevestiging met de factuur op het opgegeven e-mailadres.', 'witgoed-betaalpagina' ),
		),
		array(
			'title' => __( 'Wij verwerken je bestelling', 'witgoed-betaalpagina' ),
			'text'  => __( 'We maken je bestelling klaar en nemen contact met je op om de levering of het afhalen in te plannen.', 'witgoed-betaalpagina' ),
		),
		array(
			'title' => __( 'Vragen?', 'witgoed-betaalpagina' ),
			'text'  => __( 'Neem gerust contact met ons op als er iets niet klopt of als je iets wilt wijzigen.', 'witgoed-betaalpagina' ),
		),
	), $order );

	echo '<div class="wtbp-section wtbp-steps-wrap">';
	echo '<h2 class="wtbp-title">' . esc_html__( 'Wat gebeurt er nu?', 'witgoed-betaalpagina' ) . '</h2>';
	echo '<ol class="wtbp-steps">';
	$i = 1;
	foreach ( $steps as $step ) {
		echo '<li class="wtbp-step">';
		echo '<span class="wtbp-step-num">' . intval( $i ) . '</span>';
		echo '<span class="wtbp-step-body"><strong>' . esc_html( $step['title'] ) . '</strong>' . esc_html( $step['text'] ) . '</span>';
		echo '</li>';
		$i++;
	}
	echo '</ol>';
	echo '</div>';
}

/* =========================================================================
 * 7. STYLING (huisstijl) + KLEINE JS
 * =========================================================================
 * Laadt alleen op de betaalpagina (order-pay) en de bedankpagina
 * (order-received). Alle kleuren komen uit wtbp_brand().
 * ========================================================================= */
add_action( 'wp_enqueue_scripts', 'wtbp_assets', 20 );
function wtbp_assets() {
	if ( ! function_exists( 'is_wc_endpoint_url' ) ) {
		return;
	}
	$is_pay      = is_wc_endpoint_url( 'order-pay' );
	$is_received = is_wc_endpoint_url( 'order-received' );
	if ( ! $is_pay && ! $is_received ) {
		return;
	}

	$b = wtbp_brand();

	// Lettertype (Albert Sans) laden.
	wp_enqueue_style( 'wtbp-font', 'https://fonts.googleapis.com/css2?family=Albert+Sans:wght@400;500;600;700&display=swap', array(), null );

	$css = '
	:root{
		--wtbp-primary:' . $b['primary'] . ';
		--wtbp-primary-dark:' . $b['primary_dark'] . ';
		--wtbp-dark:' . $b['dark'] . ';
		--wtbp-accent:' . $b['accent'] . ';
		--wtbp-accent-dark:' . $b['accent_dark'] . ';
		--wtbp-surface:' . $b['surface'] . ';
		--wtbp-border:' . $b['border'] . ';
		--wtbp-text:' . $b['text'] . ';
		--wtbp-muted:' . $b['muted'] . ';
		--wtbp-radius:' . $b['radius'] . ';
		--wtbp-font:' . $b['font'] . ';
	}
	.woocommerce-order-pay .site-content,
	.woocommerce-order-received .site-content,
	.woocommerce-order-pay .entry-content,
	.woocommerce-order-received .entry-content{max-width:720px;margin-left:auto;margin-right:auto;}

	.wtbp-hero,.wtbp-thanks-hero{text-align:center;font-family:var(--wtbp-font);padding:8px 0 22px;}
	.wtbp-logo{height:44px;width:auto;margin:0 auto 18px;display:block;}
	.wtbp-hero-title,.wtbp-thanks-title{font-family:var(--wtbp-font);color:var(--wtbp-dark);font-weight:700;margin:0 0 6px;line-height:1.2;}
	.wtbp-hero-title{font-size:1.5em;}
	.wtbp-thanks-title{font-size:1.7em;}
	.wtbp-hero-sub,.wtbp-thanks-sub{color:var(--wtbp-muted);margin:0;font-size:1.02em;}
	.wtbp-check{width:64px;height:64px;line-height:64px;border-radius:50%;background:var(--wtbp-accent);color:#fff;font-size:34px;margin:0 auto 16px;box-shadow:0 6px 18px rgba(20,180,87,.35);}

	.woocommerce-order-pay .wtbp-fields,
	.woocommerce-order-pay .wtbp-section,
	.woocommerce-order-received .wtbp-section{font-family:var(--wtbp-font);color:var(--wtbp-text);}
	.wtbp-section{background:#fff;border:1px solid var(--wtbp-border);border-radius:var(--wtbp-radius);padding:22px 24px;margin:0 0 16px;box-shadow:0 1px 2px rgba(23,38,53,.04);}
	.wtbp-title{font-family:var(--wtbp-font);color:var(--wtbp-dark);font-weight:600;font-size:1.1em;margin:0 0 16px;}

	.wtbp-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 16px;}
	.wtbp-grid .form-row{float:none!important;width:auto!important;margin:0 0 14px;padding:0;}
	.wtbp-grid #billing_email_field,.wtbp-grid #billing_phone_field,.wtbp-grid #billing_company_field,
	.wtbp-grid #billing_address_1_field,.wtbp-grid #billing_address_2_field,
	.wtbp-grid #shipping_company_field,.wtbp-grid #shipping_address_1_field,.wtbp-grid #shipping_address_2_field,
	.wtbp-grid .form-row-wide{grid-column:1 / -1;}
	.wtbp-grid label{display:block;font-weight:500;color:var(--wtbp-dark);margin-bottom:5px;font-size:.95em;}
	.wtbp-grid .required{color:var(--wtbp-accent);border:0;}
	.wtbp-grid input.input-text,.wtbp-grid select,.wtbp-grid .select2-container{width:100%!important;box-sizing:border-box;}
	.wtbp-grid input.input-text{padding:11px 13px;border:1px solid #cbd5e1;border-radius:10px;font-family:var(--wtbp-font);font-size:1em;background:#fff;transition:border-color .15s,box-shadow .15s;}
	.wtbp-grid input.input-text:focus{border-color:var(--wtbp-primary);box-shadow:0 0 0 3px rgba(30,97,185,.15);outline:none;}
	.select2-container--default .select2-selection--single{border:1px solid #cbd5e1!important;border-radius:10px!important;height:44px!important;padding:5px 6px;}

	/* Vriendelijke informatiebalk (vervangt de rode gastbestelling-melding) */
	.wtbp-note{background:#eaf2fd!important;border:1px solid var(--wtbp-primary)!important;color:var(--wtbp-dark)!important;border-radius:var(--wtbp-radius)!important;padding:14px 18px!important;margin:0 0 16px!important;font-family:var(--wtbp-font)!important;list-style:none!important;}
	.wtbp-note li{list-style:none!important;margin:0!important;padding:0!important;color:var(--wtbp-dark)!important;}
	.wtbp-note::before,.wtbp-note li::before{display:none!important;content:none!important;}

	.wtbp-toggle-row{margin:2px 2px 18px!important;}
	.wtbp-toggle-row label{cursor:pointer;font-weight:500;color:var(--wtbp-dark);display:inline-flex;align-items:center;gap:8px;}

	/* Betaalmethoden-blok */
	.woocommerce-order-pay ul.wc_payment_methods{border:1px solid var(--wtbp-border);border-radius:var(--wtbp-radius);background:#fff;padding:6px 18px;margin:0 0 16px;}
	.woocommerce-order-pay .payment_box{background:var(--wtbp-surface)!important;border-radius:10px;}
	.woocommerce-order-pay .payment_box::before{border-bottom-color:var(--wtbp-surface)!important;}

	/* Primaire actieknop (Betalen) in merkgroen */
	.woocommerce-order-pay #payment #place_order,
	.woocommerce-order-pay .woocommerce #place_order,
	.woocommerce-order-pay button.button.alt,
	.woocommerce-order-received .woocommerce-button.button{
		background:var(--wtbp-accent)!important;border:0!important;color:#fff!important;
		font-family:var(--wtbp-font)!important;font-weight:600!important;font-size:1.05em!important;
		padding:14px 26px!important;border-radius:10px!important;width:100%;box-shadow:0 4px 14px rgba(20,180,87,.30);
		transition:background .15s,transform .05s;cursor:pointer;}
	.woocommerce-order-pay #payment #place_order:hover,
	.woocommerce-order-pay button.button.alt:hover{background:var(--wtbp-accent-dark)!important;}
	.woocommerce-order-pay #payment #place_order:active{transform:translateY(1px);}

	/* Besteloverzicht-tabel netjes */
	.woocommerce-order-pay .shop_table,
	.woocommerce-order-received .woocommerce-table--order-details,
	.woocommerce-order-received .woocommerce-order-overview{font-family:var(--wtbp-font);border-radius:var(--wtbp-radius);overflow:hidden;}
	.woocommerce-order-received ul.woocommerce-order-overview{border:1px solid var(--wtbp-border);border-radius:var(--wtbp-radius);background:#fff;padding:18px 22px;}
	.woocommerce-order-received .woocommerce-order-overview strong{color:var(--wtbp-dark);}

	/* Wat gebeurt er nu? */
	.wtbp-steps{list-style:none;margin:0;padding:0;counter-reset:none;}
	.wtbp-step{display:flex;gap:14px;align-items:flex-start;padding:12px 0;border-bottom:1px solid var(--wtbp-border);}
	.wtbp-step:last-child{border-bottom:0;}
	.wtbp-step-num{flex:0 0 auto;width:28px;height:28px;line-height:28px;text-align:center;border-radius:50%;background:var(--wtbp-primary);color:#fff;font-weight:600;font-size:.9em;}
	.wtbp-step-body{color:var(--wtbp-text);}
	.wtbp-step-body strong{display:block;color:var(--wtbp-dark);margin-bottom:2px;}

	@media(max-width:600px){
		.wtbp-grid{grid-template-columns:1fr;}
		.wtbp-thanks-title{font-size:1.4em;}
	}
	';

	wp_register_style( 'wtbp-inline', false );
	wp_enqueue_style( 'wtbp-inline' );
	wp_add_inline_style( 'wtbp-inline', $css );

	// JS alleen op de betaalpagina (velden verplaatsen + verzendadres in-/uitklappen).
	if ( $is_pay ) {
		$js = "
		(function(){
			function ready(fn){ if(document.readyState!='loading'){fn();}else{document.addEventListener('DOMContentLoaded',fn);} }
			ready(function(){
				// Gastbestelling-melding omzetten naar rustige informatiebalk.
				document.querySelectorAll('.woocommerce-error, .woocommerce-info, .woocommerce-message, .wc-block-components-notice-banner').forEach(function(box){
					var t=(box.textContent||'');
					if(t.indexOf('persoonlijke betaalpagina')!==-1||t.indexOf('gastbestelling')!==-1){
						box.className='wtbp-note';
					}
				});
				var fields=document.getElementById('wtbp-fields');
				if(fields){
					var methods=document.querySelector('.wc_payment_methods, #payment .payment_methods');
					if(methods&&methods.parentNode){methods.parentNode.insertBefore(fields,methods);}
					var cb=document.getElementById('wtbp_ship_to_different');
					var ship=document.getElementById('wtbp-shipping');
					if(cb&&ship){cb.addEventListener('change',function(){ship.style.display=cb.checked?'':'none';});}
				}
			});
		})();
		";
		wp_add_inline_script( 'jquery-core', $js );
	}
}

/* =========================================================================
 * 8. AUTOMATISCHE UPDATES (zelf-hostend)
 * =========================================================================
 * Laat WordPress periodiek WTBP_UPDATE_URL controleren. Staat daar een
 * hogere versie, dan verschijnt bij Plugins een normale "Update beschikbaar"-
 * knop – geen handmatige upload meer nodig. Werkt met een JSON-bestand op je
 * eigen server of met een raw JSON-URL van GitHub.
 * ========================================================================= */
if ( ! class_exists( 'WTBP_Updater' ) ) {

	class WTBP_Updater {

		private $file;
		private $basename;
		private $slug;

		public function __construct( $file ) {
			$this->file     = $file;
			$this->basename = plugin_basename( $file );          // map/bestand.php
			$this->slug     = dirname( $this->basename );        // mapnaam
			if ( '.' === $this->slug ) {
				$this->slug = basename( $file, '.php' );
			}

			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
			add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
			add_filter( 'upgrader_source_selection', array( $this, 'fix_folder_name' ), 10, 4 );
			add_action( 'upgrader_process_complete', array( $this, 'clear_cache' ), 10, 2 );
			// "Opnieuw controleren" (Dashboard → Updates) verse check laten doen.
			add_action( 'load-update-core.php', array( $this, 'force_fresh_check' ) );
		}

		/** Cache legen zodat "Opnieuw controleren" direct GitHub raadpleegt. */
		public function force_fresh_check() {
			$url = $this->update_url();
			if ( '' !== $url ) {
				delete_transient( 'wtbp_update_' . md5( $url ) );
			}
		}

		/** URL naar het update-JSON (leeg = uit). */
		private function update_url() {
			$url = defined( 'WTBP_UPDATE_URL' ) ? WTBP_UPDATE_URL : '';
			return trim( (string) apply_filters( 'wtbp_update_url', $url ) );
		}

		/** Haal de metadata op (met korte cache om de server te ontzien). */
		private function get_remote() {
			$url = $this->update_url();
			if ( '' === $url ) {
				return false;
			}

			$cache_key = 'wtbp_update_' . md5( $url );
			$cached    = get_transient( $cache_key );
			if ( false !== $cached ) {
				return 'none' === $cached ? false : $cached;
			}

			$response = wp_remote_get( $url, array(
				'timeout' => 15,
				'headers' => array( 'Accept' => 'application/json' ),
			) );

			if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				set_transient( $cache_key, 'none', 5 * MINUTE_IN_SECONDS );
				return false;
			}

			$data = json_decode( wp_remote_retrieve_body( $response ) );
			if ( empty( $data ) || empty( $data->version ) || empty( $data->download_url ) ) {
				set_transient( $cache_key, 'none', 5 * MINUTE_IN_SECONDS );
				return false;
			}

			set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );
			return $data;
		}

		/** Voeg de update toe aan de lijst als er een hogere versie is. */
		public function check_for_update( $transient ) {
			if ( empty( $transient->checked ) ) {
				return $transient;
			}

			$remote  = $this->get_remote();
			$current = isset( $transient->checked[ $this->basename ] ) ? $transient->checked[ $this->basename ] : '';

			if ( $remote && $current && version_compare( $remote->version, $current, '>' ) ) {
				$obj               = new stdClass();
				$obj->slug         = $this->slug;
				$obj->plugin       = $this->basename;
				$obj->new_version  = $remote->version;
				$obj->package      = $remote->download_url;
				$obj->url          = isset( $remote->homepage ) ? $remote->homepage : '';
				$obj->tested       = isset( $remote->tested ) ? $remote->tested : '';
				$obj->requires     = isset( $remote->requires ) ? $remote->requires : '';
				$obj->requires_php = isset( $remote->requires_php ) ? $remote->requires_php : '';
				$transient->response[ $this->basename ] = $obj;
			}

			return $transient;
		}

		/** Vult het "Details bekijken"-scherm van de plugin. */
		public function plugin_info( $result, $action, $args ) {
			if ( 'plugin_information' !== $action || empty( $args->slug ) || $args->slug !== $this->slug ) {
				return $result;
			}

			$remote = $this->get_remote();
			if ( ! $remote ) {
				return $result;
			}

			$info               = new stdClass();
			$info->name         = isset( $remote->name ) ? $remote->name : 'Apparatenman Betaal- & Bedankpagina';
			$info->slug         = $this->slug;
			$info->version      = $remote->version;
			$info->author       = isset( $remote->author ) ? $remote->author : 'Apparatenman';
			$info->requires     = isset( $remote->requires ) ? $remote->requires : '';
			$info->tested       = isset( $remote->tested ) ? $remote->tested : '';
			$info->requires_php = isset( $remote->requires_php ) ? $remote->requires_php : '';
			$info->last_updated = isset( $remote->last_updated ) ? $remote->last_updated : '';
			$info->download_link = $remote->download_url;
			$info->sections     = isset( $remote->sections ) ? (array) $remote->sections : array( 'changelog' => '' );

			return $info;
		}

		/**
		 * Zorg dat de uitgepakte map de juiste naam heeft (belangrijk bij o.a.
		 * GitHub-zips die een andere mapnaam gebruiken).
		 */
		public function fix_folder_name( $source, $remote_source, $upgrader, $args = array() ) {
			if ( empty( $args['plugin'] ) || $args['plugin'] !== $this->basename ) {
				return $source;
			}
			global $wp_filesystem;
			if ( ! $wp_filesystem ) {
				return $source;
			}
			$desired = trailingslashit( $remote_source ) . $this->slug . '/';
			if ( untrailingslashit( $source ) === untrailingslashit( $desired ) ) {
				return $source;
			}
			if ( $wp_filesystem->move( $source, $desired ) ) {
				return $desired;
			}
			return $source;
		}

		/** Cache leegmaken na een update, zodat de melding verdwijnt. */
		public function clear_cache( $upgrader, $options ) {
			$action = isset( $options['action'] ) ? $options['action'] : '';
			$type   = isset( $options['type'] ) ? $options['type'] : '';
			if ( 'update' === $action && 'plugin' === $type ) {
				$url = $this->update_url();
				if ( '' !== $url ) {
					delete_transient( 'wtbp_update_' . md5( $url ) );
				}
			}
		}
	}

	add_action( 'admin_init', function () {
		new WTBP_Updater( __FILE__ );
	} );
}
